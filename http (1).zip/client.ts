import axios from 'axios';

// URL сервера
const SERVER_URL = 'http://localhost:3000/data';

// Функция для отправки GET-запроса
async function fetchData() {
    try {
        const response = await axios.get(SERVER_URL);
        console.log('Ответ от сервера:', response.data);
    } catch (error) {
        console.error('Ошибка при запросе:', error);
    }
}

// Вызов функции
fetchData();
