import { createServer, IncomingMessage, ServerResponse } from 'http';

// Порт для сервера
const PORT = 3000;

// Создаем сервер
const server = createServer((req: IncomingMessage, res: ServerResponse) => {
    // Логируем запросы
    console.log(`Получен запрос: ${req.method} ${req.url}`);

    // Ответ на запрос
    if (req.url === '/data' && req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: 'Hello from the server!' }));
    } else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Страница не найдена');
    }
});

// Запуск сервера
server.listen(PORT, () => {
    console.log(`Сервер запущен на http://localhost:${PORT}`);
});
